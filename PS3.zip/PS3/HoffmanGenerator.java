import java.io.*;
import java.util.*;

public class HoffmanGenerator implements Huffman {

    public Map<Character, Long> countFrequencies(String pathName) throws IOException {
        BufferedReader input = new BufferedReader(new FileReader(pathName));
        Map<Character, Long> charCounts = new TreeMap<Character, Long>();
        try {
            int current = input.read();
            while (current != -1) {
                Character ch = (char) current;
                if (charCounts.containsKey(ch)) {
                    charCounts.put(ch, charCounts.get(ch) + 1);
                } else {
                    charCounts.put(ch, (long) 1);
                }
                current = input.read();
            }
        } catch (IOException e) {
            System.out.println("caught an error");
            throw new IOException(e);
        }
        finally{
            input.close();
        }
        return charCounts;

    }

    public BinaryTree<CodeTreeElement> makeCodeTree(Map<Character, Long> frequencies) {
        treeComperator comp = new treeComperator();
        //PriorityQueue<BinaryTree<CodeTreeElement>> charFreq = new PriorityQueue<BinaryTree<CodeTreeElement>((CodeTreeElement cte1, CodeTreeElement cte2) -> Math.toIntExact(cte2.myFrequency - cte1.myFrequency));
        PriorityQueue<BinaryTree<CodeTreeElement>> charFreq = new PriorityQueue<>(comp);

        for (Map.Entry<Character, Long> entry : frequencies.entrySet()) {
            char character = entry.getKey();
            long frequency = entry.getValue();
            BinaryTree<CodeTreeElement> element = new BinaryTree<CodeTreeElement>(new CodeTreeElement(frequency, character));
            //element.getData().myFrequency = frequency;
            //element.getData().myChar = character;
            charFreq.add(element);
        }
        while (charFreq.size() > 1) {
            BinaryTree<CodeTreeElement> tf = charFreq.remove();
            BinaryTree<CodeTreeElement> ts = charFreq.remove();
            BinaryTree<CodeTreeElement> T = new BinaryTree<CodeTreeElement>(new CodeTreeElement(tf.getData().myFrequency + ts.getData().myFrequency, null), tf, ts);
            charFreq.add(T);
        }
        return charFreq.remove();
    }

    @Override
    public Map<Character, String> computeCodes(BinaryTree<CodeTreeElement> codeTree) {
        String path = "";
        Map<Character, String> codes = new HashMap<Character, String>();
        helcode(codes, path, codeTree);
        return codes;
    }

    /**
     * Helper for fringe, adding fringe data to the list
     */
    private void helcode(Map<Character, String> codes, String path, BinaryTree<CodeTreeElement> root) {
        if (root.isLeaf()) { //Potentialy make sure that the node is not null and that it's not already included in the map
            codes.put(root.getData().myChar, path);
        } else {
            if (root.hasLeft()) {
                helcode(codes, path + "0", root.getLeft());
            }
            if (root.hasRight()) {
                helcode(codes, path + "1", root.getRight());
            }
        }
    }

    @Override
    public void compressFile(Map<Character, String> codeMap, String pathName, String compressedPathName) throws IOException {
        BufferedReader input = new BufferedReader(new FileReader(pathName));
        BufferedBitWriter bitOutput = new BufferedBitWriter(compressedPathName);
        try {
            int next;
            while ((next=input.read()) != -1) {
                Character ch = (char)next;
                String compCode = codeMap.get(ch);
                for (int i = 0; i < compCode.length(); i++) {
                    if (compCode.charAt(i) == '1') {
                        bitOutput.writeBit(true);
                    } else bitOutput.writeBit(false);
                }
            }
        } catch (Exception e) {
            System.out.println("CompressorFile error: " + e);
        } finally {
            input.close();
            bitOutput.close();
        }
    }


    @Override
    public void decompressFile(String compressedPathName, String decompressedPathName, BinaryTree<CodeTreeElement> codeTree) throws IOException {
        BufferedBitReader bitInput = new BufferedBitReader(compressedPathName);
        BufferedWriter output = new BufferedWriter(new FileWriter(decompressedPathName));
        String codeToWrite = "";
        BinaryTree<CodeTreeElement> current = codeTree;
        try {
            while (bitInput.hasNext()) {
                if (bitInput.readBit() == true) {
                    current = current.getRight();
                } else current = current.getLeft();

                if (current.isLeaf()) {
                    output.write(current.getData().myChar);
                    current = codeTree;
                }
            }
        } catch(Exception e) {
            System.out.println("Decompressor Error: " + e);
        }
        finally {
            bitInput.close();
            output.close();
        }
    }
    // run compression and decompression
    public void test(String filePath, String compressedFilePath, String decompressedFilePath) throws IOException {
        Map<Character, Long> freqMap = countFrequencies(filePath + ".txt");
        System.out.println("Frequency map: \n" + freqMap);
        BinaryTree<CodeTreeElement> codetree = makeCodeTree(freqMap);
        System.out.println("Code tree: \n" + codetree);
        Map<Character, String> codeMap = computeCodes(codetree);
        System.out.println("Code map: \n" + codeMap);
        compressFile(codeMap, filePath + ".txt", filePath + compressedFilePath + ".txt");
        decompressFile(filePath + compressedFilePath + ".txt", filePath + decompressedFilePath + ".txt", codetree);
        System.out.println("*End of test*");
    }

    public static void main(String[] args) throws IOException {
        HoffmanGenerator Hoffen = new HoffmanGenerator();
        String fileName1 ="PS3/USConstitution";
        String filePa1c = "_compressed";
        String filePa1d = "_decompressed";
        String fileName2 ="WarAndPeace";
        Hoffen.test(fileName1,filePa1c,filePa1d);

    }
}