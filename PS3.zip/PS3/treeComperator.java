import java.util.Comparator;

public class treeComperator implements Comparator<BinaryTree<CodeTreeElement>> {

    @Override
    public int compare(BinaryTree<CodeTreeElement> t1, BinaryTree<CodeTreeElement> t2) {
        Long t1f = t1.getData().getFrequency();
        Long t2f = t2.getData().getFrequency();
        if (t1f.compareTo(t2f)<0) {
            return -1;
        }
        else if (t1f.equals(t2f)){
            return 0;
        }
        else {
            return 1;
        }
    }
}
